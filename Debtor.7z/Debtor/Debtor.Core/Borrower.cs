﻿using System;

namespace Debtor.Core
{
    public class Borrower
    {
        public string Name { get; set; }

        public decimal Amount { get; set; }

        public decimal BeginningAmount { get; set; }

        public decimal Percentage { get; set; }

        public DateTime LoanDate { get; set; }

        public decimal Interest { get; set; }

        public override string ToString()
        {
            return Name + ";" + BeginningAmount.ToString() + ";" + Amount.ToString() + ";" + Percentage.ToString() + ";" + Interest.ToString() + ";" + LoanDate.ToString();
        }
    }
}
