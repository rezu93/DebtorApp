﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Debtor.Core
{
    public class BorrowerManager
    {
        private List<Borrower> Borrowers { get; set; }

        private string FileName { get; set; } = "borrowers.txt";

        public string Summary { get; set; }

        public string SummaryInterest { get; set; }

        public string SummaryOfAll { get; set; }

        public BorrowerManager()
        {
            Borrowers = new List<Borrower>();

            if (!File.Exists(FileName))
            {
                return;
            }

            var fileLines = File.ReadAllLines(FileName);

            foreach (var line in fileLines)
            {
                var lineItems = line.Split(';');

                if (decimal.TryParse(lineItems[1], out var beginningAmountInDecimal) && (decimal.TryParse(lineItems[2], out var amountInDecimal) && (decimal.TryParse(lineItems[3], out var percentageInDecimal) &&  
                   (decimal.TryParse(lineItems[4], out var interestInDecimal) && (DateTime.TryParse(lineItems[5], out var loandate))))))
                {
                    LoadFromFile(lineItems[0], beginningAmountInDecimal, amountInDecimal, percentageInDecimal, interestInDecimal, loandate);
                }
            }
        }

        public void AddBorrower(string name, decimal begginingAmount, decimal amount, decimal percentage, bool shouldSaveToFile = true)
        {
            var borrower = new Borrower
            {
                Name = name,
                BeginningAmount = begginingAmount,
                Amount = amount,
                Percentage = percentage
            };

            Borrowers.Add(borrower);

            borrower.LoanDate = DateTime.Now;

            if (shouldSaveToFile)
            {
                File.AppendAllLines(FileName, new List<string> { borrower.ToString() });
            }

        }
        public void LoadFromFile(string name, decimal begginingAmount, decimal amount, decimal percentage, decimal interest, DateTime loanDate, bool shouldSaveToFile = true)
        {
            var borrower = new Borrower
            {
                Name = name,
                BeginningAmount = begginingAmount,
                Amount = amount,
                Percentage = percentage,
                Interest = interest,
                LoanDate = loanDate
            };

            Borrowers.Add(borrower);

        }

        public void DeleteBorrower(string name, decimal amount, bool shouldSaveToFile = true)
        {
            foreach (var borrower in Borrowers)
            {
                if (borrower.Name == name)
                {
                    borrower.Amount = borrower.Amount - amount;
                    if (borrower.Amount <= 0)
                    {
                        Console.WriteLine("Dłużnik: " + borrower.Name + " oddał swój dług i został usunięty z listy dłużników.");
                        Borrowers.Remove(borrower);
                    }
                    else
                    {
                        Console.WriteLine("Obniżono dług Twojego dłużnika: " + borrower.Name + " o " + amount);
                    }
                    break;
                }
            }

            var borrowersToSave = new List<string>();
            if (shouldSaveToFile)
            {
                foreach (var borrower in borrowersToSave)
                {
                    borrowersToSave.Add(borrower.ToString());
                }
                //File.Delete(FileName);
                //File.WriteAllLines(FileName, borrowersToSave);
            }
        }
        public List<string> ListBorrowers()
        {
            var borrowersString = new List<string>();
            var indexer = 1;

            foreach (var borrower in Borrowers)
            {
                Interest();
                var interest = borrower.Interest.ToString("0.00");
                var borrowerString = indexer + ", " + borrower.Name + " - " + borrower.Amount + " zł" + " Oprocentowanie: " + borrower.Percentage + "% Odsetki: " + interest + " Data pożyczki: " + borrower.LoanDate;
                indexer++;

                borrowersString.Add(borrowerString);
            }

            return borrowersString;
        }

        public void SumOfAllLoan()
        {
            var summary = default(decimal);
            var summaryInterest = default(decimal);

            foreach (var borrower in Borrowers)
            {
                Interest();
                summary = summary + borrower.Amount;
                summaryInterest = summaryInterest + borrower.Interest;
            }
            Summary = summary.ToString("0.00");
            SummaryInterest = summaryInterest.ToString("0.00");
            var summaryOfAll = summary + summaryInterest;
            SummaryOfAll = summaryOfAll.ToString("0.00");

        }

        public void Interest()
        {
            foreach (var borrower in Borrowers)
            {
                var percentage = borrower.Percentage;
                var dayDifference = (int)((DateTime.Now - borrower.LoanDate).TotalDays);
                borrower.Interest = borrower.BeginningAmount * (percentage / 365) * dayDifference / 100;
            }
        }

        public List<string> FileList()
        {
            var borrowersString = new List<string>();

            File.Delete(FileName);

            foreach (var borrower in Borrowers)
            {
                var interest = borrower.Interest.ToString("0.00");
                var borrowerString = borrower.Name + ";" + borrower.BeginningAmount + ";" + borrower.Amount + ";" + borrower.Percentage + ";" + interest + ";" + borrower.LoanDate;

                borrowersString.Add(borrowerString);
                File.WriteAllLines(FileName, borrowersString);
            }

            return borrowersString;
        }

        //wyśietlanie sumy wszystkich długów - zrobione
        //odejmowanie kwoty od istniejącego dłużnika - zrobione
        //odsetki, zapisujesz date kiedy pożyczył(datetimenow) np. 5% co miesiąc - zrobione
        //naprawa aplikacji, aby poprawnie odczytywała i zapisywała do pliku - zrobione
    }
}
